const express = require('express');
const routerAdmin = express.Router();
const AdminControllers = require('../controllers/user/admin_ctll');

routerAdmin.get('/homeAdmin', AdminControllers.homePageAdmin);

module.exports = routerAdmin;