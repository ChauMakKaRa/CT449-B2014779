
class indexControllers {
    pagehome(req, res) {
      res.json('page home');
    }

    
}

module.exports = new indexControllers;