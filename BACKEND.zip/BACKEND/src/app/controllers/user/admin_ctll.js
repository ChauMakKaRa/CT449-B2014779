class AdminControllers {
    homePageAdmin (req, res) {
        res.json('trang admin');
    }
}



module.exports = new AdminControllers;